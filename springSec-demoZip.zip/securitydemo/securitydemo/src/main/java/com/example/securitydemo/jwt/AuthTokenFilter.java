package com.example.securitydemo.jwt;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

//-> This filter executes for ALMOST every request including login/signup.
//-> But-But JWT validation logic executes only when Authorization header contains JWT token.
//-> Means for login and signUP this will execute But WILL DO NOTHING!
public class AuthTokenFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(AuthTokenFilter.class);

    @Autowired
    private JwtUtils jwtUtils; //for using its methods

    @Autowired
    //From where its Implementation Coming?
    //Interface Used to load 'UserDetails' from DB
    private UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        System.out.println("@@@@@@@@@FILTER HIT");
        logger.debug("*AuthTokenFilter Called for URI: {}", request.getRequestURI());
        System.out.println("&&&Inside AutheFiltertoken");
        try{
            //Step 01: Extract JWTToken for Request Header
            String jwtToken = jwtUtils.getJwtFromHeader(request);
            logger.debug("*AuthTokenFilter.java: {}", jwtToken);

            //Step02: Check - Validity of JwtToken
            //Means: Not Null, Not Expired, Correct Signature etc.
            //Token is correct means time to fetch user details and set it to SecurityContext
            if(jwtToken != null && jwtUtils.validateJwtToken(jwtToken)){

                //Step03: Extract username stored inside JWT Token
                String userName = jwtUtils.getUserNameFromJwtToken(jwtToken);

                //Step04: This unique username will be used to fetch UserDetails from DB
                UserDetails userDetails=userDetailsService.loadUserByUsername(userName);

                //Step05: Now JWT Token is Valid - We Have UserDetails also
                //**** Will Create authentication object to set it in SecurityContext *****/
                /* Spring Security uses this object to understand:
                   -> "Current request is authenticated user" <- */

                // -> UsernamePasswordAuthenticationToken = Implementation class of Authentication interface
                // used by Spring Security to store authentication details of current user/request.

                UsernamePasswordAuthenticationToken authenticationObject =
                        new UsernamePasswordAuthenticationToken(
                                userDetails, //Principal
                                null, //Credentials
                                userDetails.getAuthorities() //Authorities
                        );

                //Optional: Adding more data about request/user in authencationObject
                authenticationObject.setDetails(
                        new WebAuthenticationDetailsSource().buildDetails(request));

                SecurityContextHolder.getContext().setAuthentication(authenticationObject);

                logger.debug("*Roles from JWT: {}", userDetails.getAuthorities());
            }
            else{
                //----> DO NOTHING : No valid JWT token found.
                /*
                    Possible cases:
                    -> Login/Signup request
                    -> Public API request
                    -> Missing token
                    -> Invalid/Expired token
                    Continue request without setting authentication.
                */
            }

        }
        catch (Exception e){
            logger.error("*Cannot set user authentication: {}", e.getMessage());
        }

        //Now: let remaining filters & controller to execute onwards... I am done
        filterChain.doFilter(request, response);
    }
}
